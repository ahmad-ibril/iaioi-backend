<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            LocationSeeder::class,
            CategorySeeder::class,
            AdminUserSeeder::class,
            DemoListingSeeder::class,
            MarketplaceDemoSeeder::class,
        ]);
    }
}
